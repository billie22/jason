
    <footer id="footer"> <!--z-index 2 bg #303030 -->
        <div class="wrap"> <!--  width:1570px; -->
            <div class="footer-gap"><!--  margin:0 20px; -->
                <div class="container">

                    <div class="content clearfix"> <!-- 1200px -->
                        <div class='content-gap'>
                            <div class="left-wrap"><!--  360 -->
                                <h1><img src="./img/logo_white.png" alt="logo"></h1>
                            </div>
                            <div class="right-wrap"><!--  840 -->
                                <div class="address-row1 clearfix">
                                    <div class="address-row1-left">
                                        <div>
                                            <span><a href="#">About Us</a></span>
                                            <span><a href="#">Privacy Policy</a></span>
                                            <span><a href="#">Contact Us 02-515-6897</a></span>
                                        </div>
                                    </div>
                                    <div class="address-row1-right">
                                        <div>
                                            <span><a href="#"><img src="./img/naver_logo_ori.png" alt=""></a></span>
                                            <span><a href="#"><img src="./img/insta_logo.png" alt=""></a></span>
                                            <span><a href="#"><img src="./img/kakao_logo.png" alt=""></a></span>                                
                                        </div>
                                    </div>
                                </div>
                                <div class="address-row2">
                                    <address>
                                        (주)제이슨여행사대표자 : 서현석사엄자등록번호 : 211-86-32052주소 : 서울특별시 강남구 학동로 520, 5층 (삼성동, 삼예빌딩)
                                        <span>&copy;Copyright by JTS. All rights reserved</span>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </footer>
</div>

<script src="./js/jason.js"></script>

</body>
</html>