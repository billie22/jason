<?
    include_once('header.php');
?>


<main id="main1-7"> <!-- 페이지 구분 아이디 -->

    <section id="section1">
        <div class="wrap">
            <div class="gap">
                <div class="container">

                    <div class='title'>
                        <h2>가족</h2>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

    
    <section id="section2">
        <div class="wrap">
            <div class="gap">
                <div class="container">

                    <!-- 회원가입 -->
                    
                </div>
            </div>
        </div>
    </section>

    


</main>





<?
    include_once('footer.php');
?>